#!/usr/bin/env bash
# Full reproduction. Runs end to end on ONE CPU core in under an hour.
# No GPU, no API key, no network access needed after fetch_source_data.sh.
set -euo pipefail
python -m pip install -r requirements.txt
bash fetch_source_data.sh
cd src
python parse_cifs.py     # CIF   -> hoip_struct.csv
python assemble.py       # merge -> hoip_master.csv
python validate_llm.py   # LLM memorisation control          (Sec. 3.6)
python run_e1.py         # Table 1, S1, S2; Fig. 2a,b        (~25 min)
python run_e2_e3.py      # Tables 2, 3, S3                   (~25 min)
python run_e3_conf.py    # Table 4, S4; Fig. 4               (~4 min)
python run_e4.py         # Fig. 3b, Fig. 5; Table S6         (~6 min)
python make_figures.py   # Figures 1-5
python ga.py             # Graphical abstract
echo "Done. Compare results/*.csv with the released copies."
