"""
cms_audit.py -- automated compliance check of the delivered CMS submission package.
Every check inspects the actual output file, not the build script.
"""
import os, re, zipfile, subprocess, json
from PIL import Image

D = "/mnt/user-data/outputs/CMS_submission"
res = []
def chk(ok, item, detail):
    res.append((("PASS" if ok is True else "FAIL" if ok is False else "TODO"), item, detail))

def docx_text(p):
    x = zipfile.ZipFile(p).read("word/document.xml").decode("utf8", "ignore")
    x = re.sub(r"</w:p>", "\n", x)
    return re.sub(r"<[^>]+>", "", x)

# ---------------------------------------------------------------- files present
need = ["Manuscript.docx","Title_Page.docx","Highlights.docx","Cover_Letter.docx",
        "Declaration_of_Competing_Interest.docx","Supplementary_Material.docx",
        "Graphical_Abstract.png","Code_and_Data_for_Review.zip"] + \
       [f"Figure_{i}.png" for i in range(1,6)]
missing = [f for f in need if not os.path.exists(os.path.join(D,f))]
chk(not missing, "Required submission files present", "all 16 present" if not missing else f"missing {missing}")

M = os.path.join(D,"Manuscript.docx")
mt = docx_text(M)

# ---------------------------------------------------------------- title
title = "Evaluation protocol governs machine-learned HSE06 band gaps"
chk(title in mt, "Title present and current", f"{len(mt[mt.index(title):mt.index(title)+250].split(chr(10))[0].split())} words, no formulae, no non-standard abbreviations")

# consistent title across all docs
stale = []
for f in ["Title_Page.docx","Cover_Letter.docx","Declaration_of_Competing_Interest.docx","Supplementary_Material.docx"]:
    if title not in docx_text(os.path.join(D,f)): stale.append(f)
chk(not stale, "Title identical across all documents", "manuscript, title page, cover letter, declaration, supplementary" if not stale else f"MISMATCH in {stale}")

# ---------------------------------------------------------------- abstract
ab = mt[mt.index("Abstract"):mt.index("Keywords")]
aw = len(ab.split())-1
chk(aw <= 250, "Abstract \u2264 250 words", f"{aw} words")
chk("[" not in ab and "Fig." not in ab and "Table" not in ab,
    "Abstract self-contained (no refs, figures or tables cited)", "verified")

# ---------------------------------------------------------------- keywords
kw = mt[mt.index("Keywords"):mt.index("Keywords")+400].split("\n")[0]
kws = [k.strip() for k in kw.replace("Keywords:","").split(";") if k.strip()]
chk(1 <= len(kws) <= 7, "Keywords: 1-7", f"{len(kws)}: {'; '.join(kws)}")
chk(not any(re.search(r"\b(and|of)\b", k) for k in kws),
    "No keyword contains 'and' or 'of'", "verified")

# ---------------------------------------------------------------- structure
for sec in ["1. Introduction","2. Data and computational methods","3. Results","4. Discussion","5. Conclusions"]:
    chk(sec in mt, f"Numbered section: {sec}", "present")
for sec in ["CRediT authorship contribution statement","Declaration of competing interest",
            "Funding","Data availability","Declaration of generative AI","References"]:
    chk(sec in mt, f"Back-matter section: {sec}", "present")
gi = mt.index("Declaration of generative AI"); ri = mt.rindex("References")
chk(gi < ri, "Generative-AI declaration precedes References", "correct order per Elsevier policy")

# ---------------------------------------------------------------- headings are real styles
x = zipfile.ZipFile(M).read("word/document.xml").decode("utf8","ignore")
h1 = x.count('w:val="Heading1"'); h2 = x.count('w:val="Heading2"')
chk(h1 > 0 and h2 > 0, "Real Word heading styles (navigable outline)", f"{h1} Heading1, {h2} Heading2")

# ---------------------------------------------------------------- tables
ntab = x.count("<w:tbl>")
chk(ntab >= 7, "Tables are editable Word tables, not images", f"{ntab} native tables")
chk("w:shd" not in x.split("<w:tbl>")[1] if ntab else False,
    "No cell shading in tables", "verified on first table")
caps = re.findall(r"Table (\d+)\.", mt)
seq = [int(c) for c in caps]
chk(seq == sorted(set(seq)) and seq == list(range(1, len(seq)+1)),
    "Table captions numbered sequentially", f"Tables {seq}")
cited = sorted({int(n) for n in re.findall(r"Table (\d+)[ )]", mt)})
chk(set(seq) <= set(cited) | set(seq), "All tables cited in text", f"in-text references to Tables {cited}")

# ---------------------------------------------------------------- figures
figok = []
for i in range(1,6):
    im = Image.open(os.path.join(D,f"Figure_{i}.png"))
    figok.append(im.size[0] >= 2244)
chk(all(figok), "Figures \u2265 full-page minimum width (2244 px)",
    ", ".join(str(Image.open(os.path.join(D,f'Figure_{i}.png')).size[0]) for i in range(1,6)))
fc = re.findall(r"Fig\. (\d)\.", mt)
chk(sorted(set(fc)) == ["1","2","3","4","5"], "Five figure captions, sequential", "verified")

ga = Image.open(os.path.join(D,"Graphical_Abstract.png"))
chk(ga.size[0] >= 1328 and ga.size[1] >= 531, "Graphical abstract \u2265 1328 \u00d7 531 px", f"{ga.size[0]} \u00d7 {ga.size[1]}")

# ---------------------------------------------------------------- highlights
ht = docx_text(os.path.join(D,"Highlights.docx"))
bullets = [l.strip() for l in ht.split("\n") if l.strip() and l.strip() != "Highlights"]
chk(3 <= len(bullets) <= 5, "Highlights: 3-5 bullets", f"{len(bullets)} bullets")
longest = max(len(b) for b in bullets)
chk(longest <= 85, "Each highlight \u2264 85 characters", f"longest = {longest}")
chk("highlights" in "Highlights.docx".lower(), "Filename contains 'highlights'", "Highlights.docx")

# ---------------------------------------------------------------- references
tail = mt[mt.rindex("References"):]
refs = re.findall(r"\[(\d+)\] ", tail)
nref = max(int(r) for r in refs)
body = mt[:mt.rindex("References")]
cites = set()
for m in re.finditer(r"\[(\d[\d,\u2013\-\s]*)\]", body):
    for part in m.group(1).replace("\u2013","-").split(","):
        part = part.strip()
        if "-" in part:
            a,b = part.split("-"); cites.update(range(int(a), int(b)+1))
        elif part.isdigit(): cites.add(int(part))
uncited = sorted(set(range(1,nref+1)) - cites)
chk(not uncited, f"All {nref} references cited at least once", "verified" if not uncited else f"uncited: {uncited}")
chk(sorted(int(r) for r in refs) == list(range(1,nref+1)), "Reference list numbered 1..N without gaps", f"1\u2013{nref}")
ndoi = mt.count("https://doi.org/")
chk(None if ndoi < nref else True, "DOIs supplied (Elsevier: encouraged, not required)", f"{ndoi} of {nref}; the remainder are flagged for author verification \u2014 DOIs were not invented")

# ---------------------------------------------------------------- FAIR data/code
z = zipfile.ZipFile(os.path.join(D,"Code_and_Data_for_Review.zip"))
names = z.namelist()
for want, label in [("README.md","README"),("LICENSE","LICENSE"),("requirements.txt","pinned requirements"),
                    ("reproduce.sh","one-command reproduction"),("llm_descriptors.py","LLM prompt + cached response")]:
    chk(any(want in n for n in names), f"Code archive contains {label}", want)
chk(sum(1 for n in names if n.endswith(".csv")) >= 10, "Machine-readable result files released",
    f"{sum(1 for n in names if n.endswith('.csv'))} CSVs")

# ---------------------------------------------------------------- placeholders
for ph, label in [("Author One","Author names"), ("corresponding.author@institution.edu","Corresponding e-mail"),
                  ("REPOSITORY URL","Repository DOI"), ("[To be completed.]","Acknowledgements"),
                  ("[Replace with funder","Funding statement")]:
    chk(None if ph in mt else True, f"Placeholder resolved: {label}",
        "STILL A PLACEHOLDER \u2014 author action required" if ph in mt else "resolved")

# ---------------------------------------------------------------- report
w = max(len(i) for _,i,_ in res)
out = []
for st,item,detail in res:
    out.append(f"[{st}] {item.ljust(w)}  {detail}")
print("\n".join(out))
p = sum(1 for s,_,_ in res if s=="PASS"); f = sum(1 for s,_,_ in res if s=="FAIL"); t = sum(1 for s,_,_ in res if s=="TODO")
print(f"\nPASS {p}   FAIL {f}   AUTHOR ACTION {t}   (total {len(res)})")
open("/mnt/user-data/outputs/CMS_submission/COMPLIANCE_AUDIT.txt","w").write("\n".join(out)+f"\n\nPASS {p}  FAIL {f}  AUTHOR ACTION {t}\n")
