#!/usr/bin/env bash
# Retrieves the primary source data: the HOIP dataset of Kim, Huan, Krishnan and
# Ramprasad, Sci. Data 4 (2017) 170057.  CITE THE ORIGINAL PAPER, not this mirror.
set -euo pipefail
mkdir -p raw && cd raw
curl -sL -o hoip.zip "https://codeload.github.com/Abdulraheem6355/HOIPs-Bandgap-Data-set/zip/refs/heads/main"
unzip -oq hoip.zip
unzip -oq HOIPs-Bandgap-Data-set-main/HOIP_cif_merge.zip -d HOIPs-Bandgap-Data-set-main/cifs
echo "CIF files: $(find HOIPs-Bandgap-Data-set-main/cifs -name '*.cif' | wc -l)  (expected 1346)"
