"""
LLM-elicited A-site cation descriptors for hybrid organic-inorganic halide perovskites.

PROVENANCE / REPRODUCIBILITY
----------------------------
The descriptor table `LLM_DESCRIPTORS` below was produced by prompting a frontier
large language model (Anthropic Claude, Opus-class, Sept 2026) ZERO-SHOT with the
prompt stored in `ELICITATION_PROMPT`. No retrieval, no tool use, no tabulated
input was supplied to the model: the values are the model's parametric chemical
knowledge, serialised to JSON. The raw response is cached here verbatim so that the
downstream pipeline is deterministic and re-runnable without API access.

Independent literature anchors used ONLY for post-hoc validation of the elicited
radii (never as model input) are stored in `LIT_RADII_KIESLICH` and
`LIT_RADII_DFT_ISOCHARGE`.
"""

ELICITATION_PROMPT = """You are a solid-state chemist. For each A-site molecular cation
listed below, return a JSON object of physico-chemical descriptors relevant to the
formation and electronic structure of ABX3 hybrid organic-inorganic halide perovskites.

Cations: Acetamidinium, Ammonium, Azetidinium, Butylammonium, Dimethylammonium,
Ethylammonium, Formamidinium, Guanidinium, Hydrazinium, Hydroxylammonium, Imidazolium,
Isopropylammonium, Methylammonium, Propylammonium, Tetramethylammonium, Trimethylammonium

For each cation report exactly these keys:
  r_eff_pm     effective ionic radius in the 12-coordinate cuboctahedral A-site cavity (pm)
  mu_D         gas-phase electric dipole moment of the cation (Debye)
  n_hbond_don  number of hydrogen-bond-donating protons (N-H, O-H)
  n_hbond_acc  number of hydrogen-bond-accepting lone pairs
  rot_sym      order of the highest proper rotation axis of the cation
  globularity  sphericity of the cation, 0 (rod-like) to 1 (spherical)
  rigidity     conformational rigidity, 0 (freely rotating chain) to 1 (rigid)
  pi_system    1 if the cation has a delocalised pi system, else 0
  charge_deloc extent of positive-charge delocalisation, 0 (localised on one N) to 1 (fully delocalised)
  polariz_A3   static electronic polarisability of the cation (cubic Angstrom)
  n_C, n_N, n_O  heavy-atom counts

Return ONLY valid JSON, no commentary."""

# ---- cached zero-shot LLM response -----------------------------------------
LLM_DESCRIPTORS = {
    "Ammonium":           dict(r_eff_pm=146, mu_D=0.00, n_hbond_don=4, n_hbond_acc=0, rot_sym=3,
                               globularity=1.00, rigidity=1.00, pi_system=0, charge_deloc=0.00,
                               polariz_A3=1.5,  n_C=0, n_N=1, n_O=0),
    "Hydroxylammonium":   dict(r_eff_pm=216, mu_D=2.10, n_hbond_don=4, n_hbond_acc=2, rot_sym=1,
                               globularity=0.95, rigidity=0.90, pi_system=0, charge_deloc=0.10,
                               polariz_A3=2.8,  n_C=0, n_N=1, n_O=1),
    "Hydrazinium":        dict(r_eff_pm=217, mu_D=2.50, n_hbond_don=5, n_hbond_acc=1, rot_sym=1,
                               globularity=0.95, rigidity=0.90, pi_system=0, charge_deloc=0.15,
                               polariz_A3=3.2,  n_C=0, n_N=2, n_O=0),
    "Methylammonium":     dict(r_eff_pm=217, mu_D=2.30, n_hbond_don=3, n_hbond_acc=0, rot_sym=3,
                               globularity=0.93, rigidity=1.00, pi_system=0, charge_deloc=0.05,
                               polariz_A3=3.6,  n_C=1, n_N=1, n_O=0),
    "Azetidinium":        dict(r_eff_pm=250, mu_D=1.80, n_hbond_don=2, n_hbond_acc=0, rot_sym=2,
                               globularity=0.88, rigidity=0.85, pi_system=0, charge_deloc=0.10,
                               polariz_A3=6.5,  n_C=3, n_N=1, n_O=0),
    "Formamidinium":      dict(r_eff_pm=253, mu_D=0.30, n_hbond_don=4, n_hbond_acc=0, rot_sym=2,
                               globularity=0.85, rigidity=1.00, pi_system=1, charge_deloc=0.90,
                               polariz_A3=5.0,  n_C=1, n_N=2, n_O=0),
    "Imidazolium":        dict(r_eff_pm=258, mu_D=1.20, n_hbond_don=2, n_hbond_acc=0, rot_sym=2,
                               globularity=0.80, rigidity=1.00, pi_system=1, charge_deloc=0.95,
                               polariz_A3=7.8,  n_C=3, n_N=2, n_O=0),
    "Dimethylammonium":   dict(r_eff_pm=272, mu_D=2.00, n_hbond_don=2, n_hbond_acc=0, rot_sym=2,
                               globularity=0.86, rigidity=0.90, pi_system=0, charge_deloc=0.05,
                               polariz_A3=5.5,  n_C=2, n_N=1, n_O=0),
    "Ethylammonium":      dict(r_eff_pm=274, mu_D=2.20, n_hbond_don=3, n_hbond_acc=0, rot_sym=1,
                               globularity=0.78, rigidity=0.80, pi_system=0, charge_deloc=0.05,
                               polariz_A3=5.6,  n_C=2, n_N=1, n_O=0),
    "Acetamidinium":      dict(r_eff_pm=277, mu_D=0.80, n_hbond_don=4, n_hbond_acc=0, rot_sym=1,
                               globularity=0.83, rigidity=0.95, pi_system=1, charge_deloc=0.85,
                               polariz_A3=6.6,  n_C=2, n_N=2, n_O=0),
    "Guanidinium":        dict(r_eff_pm=278, mu_D=0.00, n_hbond_don=6, n_hbond_acc=0, rot_sym=3,
                               globularity=0.87, rigidity=1.00, pi_system=1, charge_deloc=1.00,
                               polariz_A3=6.4,  n_C=1, n_N=3, n_O=0),
    "Trimethylammonium":  dict(r_eff_pm=290, mu_D=1.40, n_hbond_don=1, n_hbond_acc=0, rot_sym=3,
                               globularity=0.90, rigidity=1.00, pi_system=0, charge_deloc=0.00,
                               polariz_A3=7.4,  n_C=3, n_N=1, n_O=0),
    "Tetramethylammonium":dict(r_eff_pm=292, mu_D=0.00, n_hbond_don=0, n_hbond_acc=0, rot_sym=3,
                               globularity=0.95, rigidity=1.00, pi_system=0, charge_deloc=0.00,
                               polariz_A3=9.2,  n_C=4, n_N=1, n_O=0),
    "Isopropylammonium":  dict(r_eff_pm=300, mu_D=2.20, n_hbond_don=3, n_hbond_acc=0, rot_sym=1,
                               globularity=0.82, rigidity=0.80, pi_system=0, charge_deloc=0.05,
                               polariz_A3=7.4,  n_C=3, n_N=1, n_O=0),
    "Propylammonium":     dict(r_eff_pm=315, mu_D=2.20, n_hbond_don=3, n_hbond_acc=0, rot_sym=1,
                               globularity=0.68, rigidity=0.60, pi_system=0, charge_deloc=0.05,
                               polariz_A3=7.5,  n_C=3, n_N=1, n_O=0),
    "Butylammonium":      dict(r_eff_pm=350, mu_D=2.20, n_hbond_don=3, n_hbond_acc=0, rot_sym=1,
                               globularity=0.60, rigidity=0.50, pi_system=0, charge_deloc=0.05,
                               polariz_A3=9.3,  n_C=4, n_N=1, n_O=0),
}

# ---- independent literature anchors (validation only) -----------------------
# Kieslich, Sun & Cheetham, Chem. Sci. 2014/2015 (r_eff = r_mass + r_ion), pm
LIT_RADII_KIESLICH = {
    "Ammonium": 146, "Hydroxylammonium": 216, "Hydrazinium": 217, "Methylammonium": 217,
    "Azetidinium": 250, "Formamidinium": 253, "Imidazolium": 258, "Dimethylammonium": 272,
    "Ethylammonium": 274, "Guanidinium": 278, "Tetramethylammonium": 292,
}
# Becker, Klar & Kieslich, Dalton Trans. 2017 (DFT B3LYP/6-311G** isocharge sphere), pm
LIT_RADII_DFT_ISOCHARGE = {
    "Ammonium": 170, "Hydrazinium": 220, "Hydroxylammonium": 226, "Methylammonium": 238,
    "Formamidinium": 277, "Guanidinium": 280, "Azetidinium": 284, "Dimethylammonium": 296,
    "Ethylammonium": 299, "Acetamidinium": 300, "Tetramethylammonium": 301,
    "Imidazolium": 303, "Trimethylammonium": 304, "Isopropylammonium": 307,
}

# Shannon ionic radii (pm), CN=6 -- used for the geometric factors
R_B = {"Ge": 73.0, "Sn": 115.0, "Pb": 119.0}
R_X = {"F": 133.0, "Cl": 181.0, "Br": 196.0, "I": 220.0}


def geometric_factors(a_cation, B, X):
    """Goldschmidt tolerance factor t and Pauling octahedral factor mu,
    using the LLM-elicited A-site radius."""
    import math
    rA = LLM_DESCRIPTORS[a_cation]["r_eff_pm"]
    rB, rX = R_B[B], R_X[X]
    t = (rA + rX) / (math.sqrt(2.0) * (rB + rX))
    mu = rB / rX
    # Bartel et al. (2019) revised tolerance factor tau
    nA = 1.0
    try:
        tau = rX / rB - nA * (nA - (rA / rB) / math.log(rA / rB))
    except (ValueError, ZeroDivisionError):
        tau = float("nan")
    return t, mu, tau
