"""
run_e5.py -- additional controls requested at pre-submission review.

E5a  Model 0: composition-mean lookup. Predicts the training-fold mean HSE06 gap of
     the test structure's own ABX3 composition. This is the operational form of the
     85.6% variance-decomposition claim and is the floor that any ML model on a
     random split must beat.
E5b  Halide-only and halide+metal lookup baselines.
E5c  Complete feature-block ablation, including COMP+PHYS (absent from E1).
E5d  LLM descriptor permutation test: the 16 A-site descriptor vectors are shuffled
     between cations, destroying the cation-descriptor correspondence while keeping
     the marginal distribution of every descriptor identical. If the LLM gain is real,
     performance must fall back towards the COMP baseline.
E5e  Fold-level metrics with dispersion for LOCO / LOBO / LOHO.
"""
import warnings, numpy as np, pandas as pd
warnings.filterwarnings("ignore")
from features import build_features, assemble
from evaluation import make_splits, metrics
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, r2_score
import lightgbm as lgb

df = pd.read_csv("hoip_master.csv")
df, B = build_features(df)
splits = make_splits(df)
SPL = ["random", "group", "LOCO", "LOBO", "LOHO"]

def lgbm():
    return Pipeline([("imp", SimpleImputer(strategy="median")),
                     ("est", lgb.LGBMRegressor(n_estimators=500, learning_rate=0.05,
                      num_leaves=31, min_child_samples=8, subsample=0.85,
                      subsample_freq=1, colsample_bytree=0.8, reg_lambda=1.0,
                      n_jobs=1, random_state=0, verbose=-1))])

# ===================================================== E5a / E5b lookup baselines
def lookup(keycols, name):
    rows = []
    y = df.Eg_HSE.values
    for sname in SPL:
        yp = np.full(len(y), np.nan)
        for tr, te in splits[sname]:
            g = df.iloc[tr].groupby(keycols).Eg_HSE.mean()
            glob = y[tr].mean()
            gd = g.to_dict()
            sub = df.iloc[te][keycols].values
            keys = [k[0] if len(keycols) == 1 else tuple(k) for k in sub]
            yp[te] = np.array([gd.get(k, glob) for k in keys])
        m = metrics(y, yp)
        # fraction of test points with no training-fold key (fallback to global mean)
        m.update(model=name, split=sname)
        rows.append(m)
    return rows

base = []
base += lookup(["A_cation", "B", "X"], "Model 0: composition-mean lookup")
base += lookup(["X"], "Halide-only lookup")
base += lookup(["B", "X"], "Halide + metal lookup")
base += lookup(["A_cation"], "A-cation-only lookup")
bl = pd.DataFrame(base)
bl.to_csv("results_E5a_lookup_baselines.csv", index=False)
print("=== E5a/b lookup baselines ===", flush=True)
print(bl.pivot_table(index="model", columns="split", values="MAE")[SPL].round(4).to_string(), flush=True)
print(bl.pivot_table(index="model", columns="split", values="R2")[SPL].round(4).to_string(), flush=True)

# ===================================================== E5c complete ablation
FB = {
  "COMP": ["COMP"],
  "COMP+PHYS": ["COMP", "PHYS"],
  "COMP+LLM": ["COMP", "LLM"],
  "COMP+LLM+PHYS": ["COMP", "LLM", "PHYS"],
  "COMP+STRUCT": ["COMP", "STRUCT"],
  "COMP+PHYS+STRUCT": ["COMP", "PHYS", "STRUCT"],
  "COMP+LLM+PHYS+STRUCT": ["COMP", "LLM", "PHYS", "STRUCT"],
}
rows = []
for fb, names in FB.items():
    X = df[assemble(names, B)].values
    for mode in ["direct", "MFdirect", "delta"]:
        if mode == "direct":
            Xu, y, bs, yt = X, df.Eg_HSE.values, None, None
        elif mode == "MFdirect":
            Xu, y, bs, yt = np.column_stack([X, df.Eg_GGA.values]), df.Eg_HSE.values, None, None
        else:
            Xu, y = np.column_stack([X, df.Eg_GGA.values]), df.dEg.values
            bs, yt = df.Eg_GGA.values, df.Eg_HSE.values
        for sname in SPL:
            yp = np.zeros(len(y))
            for tr, te in splits[sname]:
                m = lgbm(); m.fit(Xu[tr], y[tr]); yp[te] = m.predict(Xu[te])
            yy = y
            if bs is not None:
                yp, yy = yp + bs, yt
            r = metrics(yy, yp); r.update(features=fb, mode=mode, split=sname)
            rows.append(r)
    pd.DataFrame(rows).to_csv("results_E5c_full_ablation.csv", index=False)
    print(f"[ablation] {fb} done", flush=True)
ab = pd.DataFrame(rows)
print("\n=== E5c ablation, MAE ===", flush=True)
print(ab.pivot_table(index=["mode", "features"], columns="split", values="MAE")[SPL].round(4).to_string(), flush=True)

# ===================================================== E5d LLM permutation test
rng = np.random.default_rng(0)
cats = sorted(df.A_cation.unique())
llm_cols = B["LLM"]
lut = df.drop_duplicates("A_cation").set_index("A_cation")[llm_cols]
rows = []
for rep in range(10):
    perm = rng.permutation(cats)
    mapping = dict(zip(cats, perm))
    dfp = df.copy()
    for c in llm_cols:
        dfp[c] = dfp.A_cation.map(lambda a: lut.loc[mapping[a], c])
    Xp = dfp[assemble(["COMP", "LLM"], B)].values
    for sname in ["LOHO", "LOBO", "LOCO"]:
        yp = np.zeros(len(df))
        yv = df.Eg_HSE.values
        Xu = np.column_stack([Xp, df.Eg_GGA.values])
        for tr, te in splits[sname]:
            m = lgbm(); m.fit(Xu[tr], yv[tr]); yp[te] = m.predict(Xu[te])
        rows.append(dict(rep=rep, split=sname, MAE=mean_absolute_error(yv, yp),
                         R2=r2_score(yv, yp)))
    print(f"[perm] rep {rep} done", flush=True)
pm = pd.DataFrame(rows)
pm.to_csv("results_E5d_llm_permutation.csv", index=False)
print("\n=== E5d LLM permutation (MF-direct, COMP+LLM) ===", flush=True)
print(pm.groupby("split").MAE.agg(["mean", "std", "min", "max"]).round(4).to_string(), flush=True)

# ===================================================== E5e fold-level dispersion
rows = []
for fb, names, mode in [("COMP+LLM+PHYS+STRUCT", ["COMP", "LLM", "PHYS", "STRUCT"], "direct"),
                        ("COMP+LLM+PHYS+STRUCT", ["COMP", "LLM", "PHYS", "STRUCT"], "delta")]:
    X = df[assemble(names, B)].values
    if mode == "direct":
        Xu, y = X, df.Eg_HSE.values
    else:
        Xu, y = np.column_stack([X, df.Eg_GGA.values]), df.dEg.values
    for sname in ["LOCO", "LOBO", "LOHO"]:
        col = {"LOCO": "A_cation", "LOBO": "B", "LOHO": "X"}[sname]
        for tr, te in splits[sname]:
            m = lgbm(); m.fit(Xu[tr], y[tr]); p = m.predict(Xu[te])
            if mode == "delta":
                p = p + df.Eg_GGA.values[te]; yt = df.Eg_HSE.values[te]
            else:
                yt = y[te]
            rows.append(dict(mode=mode, split=sname, fold=df.iloc[te][col].iloc[0],
                             n_test=len(te), MAE=mean_absolute_error(yt, p),
                             R2=r2_score(yt, p)))
fl = pd.DataFrame(rows)
fl.to_csv("results_E5e_fold_level.csv", index=False)
print("\n=== E5e fold-level (mean +/- sd over folds) ===", flush=True)
print(fl.groupby(["mode", "split"]).MAE.agg(["mean", "std", "min", "max"]).round(4).to_string(), flush=True)
print("\nLOHO per-halide:", flush=True)
print(fl[fl.split == "LOHO"][["mode", "fold", "n_test", "MAE", "R2"]].round(4).to_string(index=False), flush=True)
print("\nLOBO per-metal:", flush=True)
print(fl[fl.split == "LOBO"][["mode", "fold", "n_test", "MAE", "R2"]].round(4).to_string(index=False), flush=True)
print("DONE_E5", flush=True)
