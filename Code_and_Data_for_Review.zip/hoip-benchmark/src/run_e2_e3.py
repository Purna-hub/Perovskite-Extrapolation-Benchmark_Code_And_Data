import warnings, numpy as np, pandas as pd, json
warnings.filterwarnings("ignore")
from sklearn.base import clone
from features import build_features, assemble
from evaluation import (make_splits, model_zoo, metrics, cross_validate,
                        split_conformal)

df = pd.read_csv("hoip_master.csv")
df, B = build_features(df)
splits = make_splits(df)
SPL = ["random", "group", "LOCO", "LOBO", "LOHO"]

# =====================================================================  E2a
# Physically-motivated non-ML baselines for the GGA -> HSE06 upgrade.
rows = []
y = df.Eg_HSE.values
g = df.Eg_GGA.values
for sname in SPL:
    sp = splits[sname]
    # (i) constant scissor shift fitted on the training fold
    yp = np.zeros(len(y))
    for tr, te in sp:
        yp[te] = g[te] + df.dEg.values[tr].mean()
    m = metrics(y, yp); m.update(model="Scissor shift (const)", split=sname); rows.append(m)
    # (ii) linear scaling Eg_HSE = a*Eg_GGA + b
    yp = np.zeros(len(y))
    for tr, te in sp:
        a, b = np.polyfit(g[tr], y[tr], 1)
        yp[te] = a * g[te] + b
    m = metrics(y, yp); m.update(model="Linear scaling", split=sname); rows.append(m)
    # (iii) halide-resolved scissor (oracle within training halides only)
    yp = np.zeros(len(y))
    for tr, te in sp:
        med = df.iloc[tr].groupby("X").dEg.mean()
        glob = df.dEg.values[tr].mean()
        yp[te] = g[te] + df.iloc[te].X.map(med).fillna(glob).values
    m = metrics(y, yp); m.update(model="Halide-resolved scissor", split=sname); rows.append(m)
base = pd.DataFrame(rows)
base.to_csv("results_E2a_physical_baselines.csv", index=False)
print("=== E2a physical baselines: MAE (eV) ===", flush=True)
print(base.pivot_table(index="model", columns="split", values="MAE")[SPL].round(4).to_string(), flush=True)

# =====================================================================  E2b
# Model zoo on the two headline configurations.
CONFIGS = {
    "pre-DFT (C+L+P) direct":   (["COMP", "LLM", "PHYS"], "direct"),
    "pre-DFT (C+L+P) delta":    (["COMP", "LLM", "PHYS"], "delta"),
    "post-relax (C+L+P+S) delta": (["COMP", "LLM", "PHYS", "STRUCT"], "delta"),
}
rows = []
for cname, (blocks, mode) in CONFIGS.items():
    cols = assemble(blocks, B)
    X = df[cols].values
    if mode == "direct":
        Xu, yy, bs, yt = X, df.Eg_HSE.values, None, None
    else:
        Xu = np.column_stack([X, df.Eg_GGA.values])
        yy, bs, yt = df.dEg.values, df.Eg_GGA.values, df.Eg_HSE.values
    for mname, mdl in model_zoo().items():
        if mname.startswith("_skip"):
            continue
        for sname in SPL:
            try:
                a, p = cross_validate(lambda m=mdl: clone(m),
                                      Xu, yy, splits[sname], bs, yt)
                m = metrics(a, p)
            except Exception as e:
                m = dict(MAE=np.nan, RMSE=np.nan, R2=np.nan, MaxAE=np.nan)
            m.update(config=cname, model=mname, split=sname)
            rows.append(m)
            pd.DataFrame(rows).to_csv("results_E2b_model_zoo.csv", index=False)
            print(f"{cname:28s} {mname:11s} {sname:7s} MAE={m['MAE']:.4f} R2={m['R2']:.4f}", flush=True)
zoo = pd.DataFrame(rows)
print("\n=== E2b model zoo: MAE (eV) ===", flush=True)
print(zoo.pivot_table(index=["config", "model"], columns="split", values="MAE")[SPL].round(4).to_string(), flush=True)

# =====================================================================  E3
# Conformal uncertainty quantification, alpha = 0.1 (nominal 90% coverage).
import lightgbm as lgb
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
def lgbm():
    return Pipeline([("imp", SimpleImputer(strategy="median")),
                     ("est", lgb.LGBMRegressor(n_estimators=500, learning_rate=0.035,
                      num_leaves=31, min_child_samples=8, subsample=0.85,
                      subsample_freq=1, colsample_bytree=0.8, reg_lambda=1.0,
                      n_jobs=-1, random_state=0, verbose=-1))])

rows = []
for cname, (blocks, mode) in CONFIGS.items():
    cols = assemble(blocks, B)
    X = df[cols].values
    if mode == "direct":
        Xu, yy, bs, yt = X, df.Eg_HSE.values, None, None
    else:
        Xu = np.column_stack([X, df.Eg_GGA.values])
        yy, bs, yt = df.dEg.values, df.Eg_GGA.values, df.Eg_HSE.values
    for sname in SPL:
        for calib, grp in (("i.i.d. calibration", None),
                           ("group calibration", df.composition.values)):
            r, lo, hi = split_conformal(lgbm, Xu, yy, splits[sname], alpha=0.1,
                                        delta_base=bs, y_true=yt, groups=grp)
            r.update(config=cname, split=sname, calibration=calib)
            rows.append(r)
            pd.DataFrame(rows).to_csv("results_E3_conformal.csv", index=False)
            print(f"[conformal] {cname:28s} {sname:7s} {calib:19s} "
                  f"cov={r['coverage']:.3f} width={r['mean_width']:.3f}", flush=True)
print("\nDONE", flush=True)
