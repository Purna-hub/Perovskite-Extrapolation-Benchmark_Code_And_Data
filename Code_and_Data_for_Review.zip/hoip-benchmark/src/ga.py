import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, numpy as np, pandas as pd
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11})
e1=pd.read_csv("results_E1_protocol_audit.csv"); e2a=pd.read_csv("results_E2a_physical_baselines.csv")
e3=pd.read_csv("results_E3_conformal.csv")
SPL=["random","group","LOCO","LOBO","LOHO"]; LBL=["Random","Grouped","LOCO","LOBO","LOHO"]
fig=plt.figure(figsize=(8.853,3.54),dpi=300)
gs=fig.add_gridspec(1,3,width_ratios=[1.25,1,1],wspace=0.42,left=0.075,right=0.985,top=0.80,bottom=0.20)
fig.suptitle("Random cross-validation hides the only failure that matters",
             fontsize=13.5,weight="bold",y=0.955)

ax=fig.add_subplot(gs[0,0])
for m,lab,c in (("direct","Direct ML","#C1443C"),("delta",r"$\Delta$-learning","#2A6FA8")):
    s=e1[(e1["mode"]==m)&(e1.features=="C+L+P+S")]
    ax.plot(range(5),[s[s.split==x].R2.iloc[0] for x in SPL],"o-",color=c,lw=2.2,ms=6,label=lab)
ax.set_xticks(range(5)); ax.set_xticklabels(LBL,rotation=32,ha="right",fontsize=9)
ax.set_ylabel(r"$R^2$",fontsize=11); ax.set_ylim(0.25,1.03)
ax.legend(frameon=False,fontsize=9,loc="lower left")
ax.annotate("0.967",xy=(0,0.967),xytext=(0.1,0.90),fontsize=8.5,color="#C1443C")
ax.annotate("0.432",xy=(4,0.432),xytext=(2.05,0.30),fontsize=8.5,color="#C1443C")
ax.set_title("1,346 hybrid halide perovskites",fontsize=9.5,pad=5)

ax=fig.add_subplot(gs[0,1])
dl=e1[(e1["mode"]=="delta")&(e1.features=="C+L+P+S")]
ml=[dl[dl.split==x].MAE.iloc[0] for x in SPL]
ln=[e2a[(e2a.model=="Linear scaling")&(e2a.split==x)].MAE.iloc[0] for x in SPL]
x=np.arange(5); w=0.38
ax.bar(x-w/2,ml,w,color="#2A6FA8",label=r"$\Delta$-ML ($\sim$10$^4$ params)")
ax.bar(x+w/2,ln,w,color="#9AA5AD",label="Straight line (2 params)")
ax.set_xticks(x); ax.set_xticklabels(LBL,rotation=32,ha="right",fontsize=9)
ax.set_ylabel("MAE (eV)",fontsize=11); ax.legend(frameon=False,fontsize=8,loc="upper left")
ax.set_ylim(0,0.175)
ax.annotate("line wins",xy=(4.19,0.084),xytext=(2.9,0.125),fontsize=8.5,
            arrowprops=dict(arrowstyle="->",lw=1.0,color="k"))
ax.set_title("ML gain is interpolation only",fontsize=9.5,pad=5)

ax=fig.add_subplot(gs[0,2])
s=e3[(e3.config=="post-relax (C+L+P+S) delta")&(e3.calibration=="i.i.d.")]
ax.plot(range(5),[s[s.split==x].coverage.iloc[0] for x in SPL],"s-",color="#7A9E3F",lw=2.2,ms=6)
ax.axhline(0.9,c="k",ls="--",lw=1.1); ax.text(0.08,0.925,"nominal 90%",fontsize=8.5)
ax.set_xticks(range(5)); ax.set_xticklabels(LBL,rotation=32,ha="right",fontsize=9)
ax.set_ylabel("conformal coverage",fontsize=11); ax.set_ylim(0.2,1.0)
ax.set_title("Error bars fail where needed",fontsize=9.5,pad=5)
fig.savefig("/home/claude/sub/out/Graphical_Abstract.png",dpi=300,facecolor="white")
fig.savefig("/home/claude/sub/out/Graphical_Abstract.tif",dpi=300,facecolor="white")
print("ok")
